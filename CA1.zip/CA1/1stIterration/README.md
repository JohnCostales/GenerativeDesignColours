# Generative Design Colour Experiment

The goal of this project is to develop a visualisation of a experamental colour formulae. This visual can be controlled by a number of input parameters.
On this code we look at the Phyllotaxis formula which develops spiral patterns in nature more notably in plants.
